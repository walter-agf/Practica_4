# Función
def f(x):
    f = # agregar aquí el polinomio
    return f

# Variables del programa
pasos = 0 # Número de veces que se repite el ciclo
a = -4 # Limite inferior
b = -3 # Limite superior
epsilon = 0.01 # Tolerancia al error
delta = 0.0001 # Tamaño de paso

# Inicialización de la variable que contendrá el valor de la raíz
xl = a

# Evaluación iterativa de la función en la raíz sospechada
while ...
    # Actualización del número de pasos
    # Incremento de la variable que contiene la raíz
    # Evaluación iterativa de la función en la raíz sospechada

# Despliegue de los resultados

