# Función
def f(x):
    f = # agregar aquí el polinomio
    return f

# Variables del programa
pasos = 0 # Número de veces que se repite el ciclo
a = -4 # Limite inferior
b = -3 # Limite superio
epsilon = 0.01 # Tolerancia

# Evaluación de la función en los limites
f1 = f(a)
f2 = f(b)

# Verificar que existe raíz en los limites
# Hay 4 posibilidades:
# 1. Que la raíz sea a. Si f1 == 0.
# 2. Que la raíz sea b. Si f2 == 0.
# 3. Que no haya raíz. Si f1*f2 > 0 (asumiendo que hay máximo una raíz en el intervalo)
# 4. Que la raíz se encuentre en el intervalo [a,b]. Si f1*f2 < 0
if ...
    
elif ...
    
elif ...
        
elif ...
    # Busqueda de la raíz dentro del intervalo
    while ...
        # Actualización de las iteraciones
        
        # Cálculo del punto medio del intervalo        
                
        # Determinación del intervalo en el que se encuentra la raíz
        
        # Búsqueda de la raíz dentro del intervalo

# Despliegue de los resultados

